﻿namespace ProyectoFinal
{
    partial class Registro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registro));
            this.label19 = new System.Windows.Forms.Label();
            this.btnREGISTRARSE = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tbL4 = new System.Windows.Forms.TextBox();
            this.tbL3 = new System.Windows.Forms.TextBox();
            this.tbL2 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tbL1 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cbC4 = new System.Windows.Forms.ComboBox();
            this.cbC3 = new System.Windows.Forms.ComboBox();
            this.cbC2 = new System.Windows.Forms.ComboBox();
            this.cbC1 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbDESC = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbMAIL = new System.Windows.Forms.TextBox();
            this.tbTLF = new System.Windows.Forms.TextBox();
            this.tbDNI = new System.Windows.Forms.TextBox();
            this.tbNOMBRE = new System.Windows.Forms.TextBox();
            this.btnSUBIRFOTO = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.tbLink = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.cbDISTRITO = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("MV Boli", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label19.Location = new System.Drawing.Point(25, 20);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(119, 26);
            this.label19.TabIndex = 57;
            this.label19.Text = "REGISTRO";
            // 
            // btnREGISTRARSE
            // 
            this.btnREGISTRARSE.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnREGISTRARSE.Location = new System.Drawing.Point(739, 764);
            this.btnREGISTRARSE.Margin = new System.Windows.Forms.Padding(4);
            this.btnREGISTRARSE.Name = "btnREGISTRARSE";
            this.btnREGISTRARSE.Size = new System.Drawing.Size(252, 118);
            this.btnREGISTRARSE.TabIndex = 56;
            this.btnREGISTRARSE.Text = "REGISTRARSE";
            this.btnREGISTRARSE.UseVisualStyleBackColor = true;
            this.btnREGISTRARSE.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.tbL4);
            this.groupBox1.Controls.Add(this.tbL3);
            this.groupBox1.Controls.Add(this.tbL2);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.tbL1);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.groupBox1.Location = new System.Drawing.Point(16, 282);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(1017, 201);
            this.groupBox1.TabIndex = 53;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Certificados y enlaces de interes:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label17.Location = new System.Drawing.Point(8, 20);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(599, 17);
            this.label17.TabIndex = 25;
            this.label17.Text = "Inserte aqui los enlaces que desee referente a titulos, certificados, estudios, e" +
    "tc.";
            // 
            // tbL4
            // 
            this.tbL4.Location = new System.Drawing.Point(33, 144);
            this.tbL4.Margin = new System.Windows.Forms.Padding(4);
            this.tbL4.Name = "tbL4";
            this.tbL4.Size = new System.Drawing.Size(965, 23);
            this.tbL4.TabIndex = 31;
            // 
            // tbL3
            // 
            this.tbL3.Location = new System.Drawing.Point(33, 113);
            this.tbL3.Margin = new System.Windows.Forms.Padding(4);
            this.tbL3.Name = "tbL3";
            this.tbL3.Size = new System.Drawing.Size(965, 23);
            this.tbL3.TabIndex = 30;
            // 
            // tbL2
            // 
            this.tbL2.Location = new System.Drawing.Point(33, 82);
            this.tbL2.Margin = new System.Windows.Forms.Padding(4);
            this.tbL2.Name = "tbL2";
            this.tbL2.Size = new System.Drawing.Size(965, 23);
            this.tbL2.TabIndex = 29;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(8, 153);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(17, 17);
            this.label13.TabIndex = 28;
            this.label13.Text = "4";
            // 
            // tbL1
            // 
            this.tbL1.Location = new System.Drawing.Point(33, 48);
            this.tbL1.Margin = new System.Windows.Forms.Padding(4);
            this.tbL1.Name = "tbL1";
            this.tbL1.Size = new System.Drawing.Size(965, 23);
            this.tbL1.TabIndex = 25;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(8, 117);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(17, 17);
            this.label14.TabIndex = 27;
            this.label14.Text = "3";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(8, 86);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(17, 17);
            this.label15.TabIndex = 26;
            this.label15.Text = "2";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(8, 52);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(17, 17);
            this.label16.TabIndex = 25;
            this.label16.Text = "1";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label12.Location = new System.Drawing.Point(750, 673);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(14, 16);
            this.label12.TabIndex = 52;
            this.label12.Text = "4";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label11.Location = new System.Drawing.Point(750, 638);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(14, 16);
            this.label11.TabIndex = 51;
            this.label11.Text = "3";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label10.Location = new System.Drawing.Point(750, 607);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(14, 16);
            this.label10.TabIndex = 50;
            this.label10.Text = "2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label9.Location = new System.Drawing.Point(750, 572);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(14, 16);
            this.label9.TabIndex = 49;
            this.label9.Text = "1";
            // 
            // cbC4
            // 
            this.cbC4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbC4.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cbC4.FormattingEnabled = true;
            this.cbC4.Items.AddRange(new object[] {
            "Colaborador",
            "Comprometido",
            "Creativo",
            "Eficiente",
            "Entusiasta",
            "Flexible",
            "Honesto",
            "Independiente",
            "Innovador",
            "Paticipativo",
            "Productivo",
            "Puntual",
            "Respetuoso",
            "Responsable",
            "Sociable"});
            this.cbC4.Location = new System.Drawing.Point(804, 663);
            this.cbC4.Margin = new System.Windows.Forms.Padding(4);
            this.cbC4.Name = "cbC4";
            this.cbC4.Size = new System.Drawing.Size(160, 24);
            this.cbC4.TabIndex = 48;
            // 
            // cbC3
            // 
            this.cbC3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbC3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cbC3.FormattingEnabled = true;
            this.cbC3.Items.AddRange(new object[] {
            "Colaborador",
            "Comprometido",
            "Creativo",
            "Eficiente",
            "Entusiasta",
            "Flexible",
            "Honesto",
            "Independiente",
            "Innovador",
            "Paticipativo",
            "Productivo",
            "Puntual",
            "Respetuoso",
            "Responsable",
            "Sociable"});
            this.cbC3.Location = new System.Drawing.Point(804, 630);
            this.cbC3.Margin = new System.Windows.Forms.Padding(4);
            this.cbC3.Name = "cbC3";
            this.cbC3.Size = new System.Drawing.Size(160, 24);
            this.cbC3.TabIndex = 47;
            // 
            // cbC2
            // 
            this.cbC2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbC2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cbC2.FormattingEnabled = true;
            this.cbC2.Items.AddRange(new object[] {
            "Colaborador",
            "Comprometido",
            "Creativo",
            "Eficiente",
            "Entusiasta",
            "Flexible",
            "Honesto",
            "Independiente",
            "Innovador",
            "Paticipativo",
            "Productivo",
            "Puntual",
            "Respetuoso",
            "Responsable",
            "Sociable"});
            this.cbC2.Location = new System.Drawing.Point(804, 597);
            this.cbC2.Margin = new System.Windows.Forms.Padding(4);
            this.cbC2.Name = "cbC2";
            this.cbC2.Size = new System.Drawing.Size(160, 24);
            this.cbC2.TabIndex = 46;
            // 
            // cbC1
            // 
            this.cbC1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbC1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cbC1.FormattingEnabled = true;
            this.cbC1.Items.AddRange(new object[] {
            "Colaborador",
            "Comprometido",
            "Creativo",
            "Eficiente",
            "Entusiasta",
            "Flexible",
            "Honesto",
            "Independiente",
            "Innovador",
            "Paticipativo",
            "Productivo",
            "Puntual",
            "Respetuoso",
            "Responsable",
            "Sociable"});
            this.cbC1.Location = new System.Drawing.Point(804, 562);
            this.cbC1.Margin = new System.Windows.Forms.Padding(4);
            this.cbC1.Name = "cbC1";
            this.cbC1.Size = new System.Drawing.Size(160, 24);
            this.cbC1.TabIndex = 45;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label8.Location = new System.Drawing.Point(689, 533);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(315, 18);
            this.label8.TabIndex = 44;
            this.label8.Text = "Principales caresteristicas del trabajador";
            // 
            // tbDESC
            // 
            this.tbDESC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDESC.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.tbDESC.Location = new System.Drawing.Point(663, 140);
            this.tbDESC.Margin = new System.Windows.Forms.Padding(4);
            this.tbDESC.Multiline = true;
            this.tbDESC.Name = "tbDESC";
            this.tbDESC.Size = new System.Drawing.Size(370, 124);
            this.tbDESC.TabIndex = 43;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label7.Location = new System.Drawing.Point(659, 106);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label7.Size = new System.Drawing.Size(175, 18);
            this.label7.TabIndex = 42;
            this.label7.Text = "Descripcion Personal:";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.radioButton2.Location = new System.Drawing.Point(790, 64);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(115, 20);
            this.radioButton2.TabIndex = 41;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Desempleado";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.radioButton1.Location = new System.Drawing.Point(663, 64);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(91, 20);
            this.radioButton1.TabIndex = 40;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Empleado";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label6.Location = new System.Drawing.Point(659, 32);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(144, 18);
            this.label6.TabIndex = 39;
            this.label6.Text = "Situacion Laboral:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label5.Location = new System.Drawing.Point(17, 204);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 16);
            this.label5.TabIndex = 38;
            this.label5.Text = "Distrito de Residencia:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label3.Location = new System.Drawing.Point(17, 172);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 16);
            this.label3.TabIndex = 37;
            this.label3.Text = "Correo:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label4.Location = new System.Drawing.Point(17, 140);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 16);
            this.label4.TabIndex = 36;
            this.label4.Text = "Telefono:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label2.Location = new System.Drawing.Point(17, 108);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 16);
            this.label2.TabIndex = 35;
            this.label2.Text = "DNI:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(17, 76);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 16);
            this.label1.TabIndex = 34;
            this.label1.Text = "Nombres y Apellidos: ";
            // 
            // tbMAIL
            // 
            this.tbMAIL.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbMAIL.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.tbMAIL.Location = new System.Drawing.Point(179, 164);
            this.tbMAIL.Margin = new System.Windows.Forms.Padding(4);
            this.tbMAIL.Name = "tbMAIL";
            this.tbMAIL.Size = new System.Drawing.Size(197, 22);
            this.tbMAIL.TabIndex = 32;
            // 
            // tbTLF
            // 
            this.tbTLF.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbTLF.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.tbTLF.Location = new System.Drawing.Point(179, 132);
            this.tbTLF.Margin = new System.Windows.Forms.Padding(4);
            this.tbTLF.Name = "tbTLF";
            this.tbTLF.Size = new System.Drawing.Size(197, 22);
            this.tbTLF.TabIndex = 31;
            // 
            // tbDNI
            // 
            this.tbDNI.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDNI.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.tbDNI.Location = new System.Drawing.Point(179, 100);
            this.tbDNI.Margin = new System.Windows.Forms.Padding(4);
            this.tbDNI.Name = "tbDNI";
            this.tbDNI.Size = new System.Drawing.Size(196, 22);
            this.tbDNI.TabIndex = 30;
            // 
            // tbNOMBRE
            // 
            this.tbNOMBRE.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbNOMBRE.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.tbNOMBRE.Location = new System.Drawing.Point(179, 68);
            this.tbNOMBRE.Margin = new System.Windows.Forms.Padding(4);
            this.tbNOMBRE.Name = "tbNOMBRE";
            this.tbNOMBRE.Size = new System.Drawing.Size(195, 22);
            this.tbNOMBRE.TabIndex = 29;
            // 
            // btnSUBIRFOTO
            // 
            this.btnSUBIRFOTO.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnSUBIRFOTO.Location = new System.Drawing.Point(428, 243);
            this.btnSUBIRFOTO.Margin = new System.Windows.Forms.Padding(4);
            this.btnSUBIRFOTO.Name = "btnSUBIRFOTO";
            this.btnSUBIRFOTO.Size = new System.Drawing.Size(195, 31);
            this.btnSUBIRFOTO.TabIndex = 58;
            this.btnSUBIRFOTO.Text = "SUBIR FOTO";
            this.btnSUBIRFOTO.UseVisualStyleBackColor = true;
            this.btnSUBIRFOTO.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(428, 32);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(188, 206);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 59;
            this.pictureBox1.TabStop = false;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(442, 862);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(49, 20);
            this.checkBox6.TabIndex = 71;
            this.checkBox6.Text = "NO";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(226, 862);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(41, 20);
            this.checkBox5.TabIndex = 70;
            this.checkBox5.Text = "SI";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(442, 710);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(49, 20);
            this.checkBox4.TabIndex = 69;
            this.checkBox4.Text = "NO";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(226, 710);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.checkBox3.Size = new System.Drawing.Size(41, 20);
            this.checkBox3.TabIndex = 68;
            this.checkBox3.Text = "SI";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(445, 601);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(49, 20);
            this.checkBox2.TabIndex = 67;
            this.checkBox2.Text = "NO";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(226, 601);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(41, 20);
            this.checkBox1.TabIndex = 66;
            this.checkBox1.Text = "SI";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // tbLink
            // 
            this.tbLink.Location = new System.Drawing.Point(49, 940);
            this.tbLink.Margin = new System.Windows.Forms.Padding(4);
            this.tbLink.Name = "tbLink";
            this.tbLink.Size = new System.Drawing.Size(614, 22);
            this.tbLink.TabIndex = 65;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label20.Location = new System.Drawing.Point(184, 902);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(358, 24);
            this.label20.TabIndex = 64;
            this.label20.Text = "ENLACE AL CARNET DE VACUNACION";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label21.Location = new System.Drawing.Point(67, 748);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(610, 96);
            this.label21.TabIndex = 63;
            this.label21.Text = resources.GetString("label21.Text");
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label22.Location = new System.Drawing.Point(97, 638);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(560, 48);
            this.label22.TabIndex = 62;
            this.label22.Text = "En las ultimas dos semanas. Has tenido contacto con alguien que\r\n dio positivo en" +
    " COVID-19? Esta en cuarentena?\r\n";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label23.Location = new System.Drawing.Point(137, 505);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(456, 72);
            this.label23.TabIndex = 61;
            this.label23.Text = "En las ultimas dos semana. \r\nHas dado positivo en COVID-19 o\r\nactualmente esta si" +
    "endo monitoreado por COVID-19?\r\n";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(997, 22);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(36, 36);
            this.button1.TabIndex = 72;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // cbDISTRITO
            // 
            this.cbDISTRITO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbDISTRITO.FormattingEnabled = true;
            this.cbDISTRITO.Items.AddRange(new object[] {
            "Ancón",
            "Ate Vitarte",
            "Barranco",
            "Bellavista",
            "Breña",
            "Callao",
            "Carabayllo",
            "Carmen de La Legua-Reynoso",
            "Cercado",
            "Chaclacayo",
            "Chorrillos",
            "Cieneguilla",
            "Comas",
            "El Agustino",
            "Independencia",
            "Jesús María",
            "La Molina",
            "La Perla",
            "La Punta",
            "La Victoria",
            "Lince",
            "Los  Olivos",
            "Lurigancho",
            "Lúrin ",
            "Magdalena",
            "Mi Peru",
            "Miraflores",
            "Pachacamac",
            "Pblo. Libre",
            "Pta. Hermosa",
            "Pta. Negra",
            "Pte. Piedra",
            "Pucusana",
            "Rimac",
            "S. J. de Lurigancho",
            "S. J. de Miraflores",
            "S. M. Porres",
            "San Bartolo",
            "San Borja",
            "San Isidro",
            "San Luis",
            "San Miguel",
            "Sta. Anita",
            "Sta. María",
            "Sta. Rosa",
            "Surco",
            "Surquillo",
            "V.M. de Triunfo",
            "Ventanilla",
            "Villa el Salvador"});
            this.cbDISTRITO.Location = new System.Drawing.Point(179, 201);
            this.cbDISTRITO.Name = "cbDISTRITO";
            this.cbDISTRITO.Size = new System.Drawing.Size(197, 24);
            this.cbDISTRITO.TabIndex = 73;
            // 
            // Registro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1081, 499);
            this.Controls.Add(this.cbDISTRITO);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.checkBox6);
            this.Controls.Add(this.checkBox5);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.tbLink);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnSUBIRFOTO);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.btnREGISTRARSE);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.cbC4);
            this.Controls.Add(this.cbC3);
            this.Controls.Add(this.cbC2);
            this.Controls.Add(this.cbC1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.tbDESC);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbMAIL);
            this.Controls.Add(this.tbTLF);
            this.Controls.Add(this.tbDNI);
            this.Controls.Add(this.tbNOMBRE);
            this.Name = "Registro";
            this.Text = "Registro";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnREGISTRARSE;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox tbL4;
        private System.Windows.Forms.TextBox tbL3;
        private System.Windows.Forms.TextBox tbL2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tbL1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cbC4;
        private System.Windows.Forms.ComboBox cbC3;
        private System.Windows.Forms.ComboBox cbC2;
        private System.Windows.Forms.ComboBox cbC1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbDESC;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbMAIL;
        private System.Windows.Forms.TextBox tbTLF;
        private System.Windows.Forms.TextBox tbDNI;
        private System.Windows.Forms.TextBox tbNOMBRE;
        private System.Windows.Forms.Button btnSUBIRFOTO;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox tbLink;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox cbDISTRITO;
    }
}